create view allfile as
  select `vediorent`.`fileinfo`.`id`     AS `id`,
         `vediorent`.`fileinfo`.`status` AS `status`,
         `vediorent`.`videoinfo`.`name`  AS `name`,
         `vediorent`.`fileinfo`.`vid`    AS `vid`
  from (`vediorent`.`fileinfo` join `vediorent`.`videoinfo` on ((`vediorent`.`fileinfo`.`vid` =
                                                                 `vediorent`.`videoinfo`.`id`)));

