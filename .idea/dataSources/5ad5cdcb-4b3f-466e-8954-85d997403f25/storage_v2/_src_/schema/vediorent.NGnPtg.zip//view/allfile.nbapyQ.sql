create view allfile as
  select `vediorent`.`fileinfo`.`id`     AS `id`,
         `vediorent`.`fileinfo`.`status` AS `status`,
         `vediorent`.`vedioinfo`.`name`  AS `name`,
         `vediorent`.`fileinfo`.`vid`    AS `vid`
  from (`vediorent`.`fileinfo` join `vediorent`.`vedioinfo` on ((`vediorent`.`fileinfo`.`vid` =
                                                                 `vediorent`.`vedioinfo`.`id`)));

