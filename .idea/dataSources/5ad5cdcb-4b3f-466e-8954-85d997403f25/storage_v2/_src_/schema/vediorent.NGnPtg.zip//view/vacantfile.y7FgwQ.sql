create view vacantfile as
  select `vediorent`.`vedioinfo`.`name`  AS `name`,
         `vediorent`.`fileinfo`.`id`     AS `fid`,
         `vediorent`.`vedioinfo`.`price` AS `price`
  from (`vediorent`.`fileinfo` join `vediorent`.`vedioinfo` on ((`vediorent`.`vedioinfo`.`id` =
                                                                 `vediorent`.`fileinfo`.`vid`)))
  where (`vediorent`.`fileinfo`.`status` = 1);

