create view vacantfile as
  select `vediorent`.`videoinfo`.`name`  AS `name`,
         `vediorent`.`fileinfo`.`id`     AS `fid`,
         `vediorent`.`videoinfo`.`price` AS `price`
  from (`vediorent`.`fileinfo` join `vediorent`.`videoinfo` on ((`vediorent`.`videoinfo`.`id` =
                                                                 `vediorent`.`fileinfo`.`vid`)))
  where (`vediorent`.`fileinfo`.`status` = 1);

