create view videorecording as
  select `vediorent`.`videoinfo`.`name`      AS `name`,
         `vediorent`.`videoinfo`.`price`     AS `price`,
         `vediorent`.`videoinfo`.`inventory` AS `inventory`
  from `vediorent`.`videoinfo`;

