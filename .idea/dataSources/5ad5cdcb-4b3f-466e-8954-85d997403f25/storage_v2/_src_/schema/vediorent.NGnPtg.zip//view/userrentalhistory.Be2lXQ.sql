create view userrentalhistory as
  select `vediorent`.`recordinfo`.`username` AS `username`,
         `vediorent`.`videoinfo`.`name`      AS `name`,
         `vediorent`.`recordinfo`.`fid`      AS `fid`,
         `vediorent`.`recordinfo`.`lend`     AS `lend`,
         `vediorent`.`recordinfo`.`back`     AS `back`,
         `vediorent`.`recordinfo`.`amount`   AS `amount`,
         `vediorent`.`recordinfo`.`deposit`  AS `deposit`
  from ((`vediorent`.`recordinfo` join `vediorent`.`videoinfo`) join `vediorent`.`fileinfo`)
  where ((`vediorent`.`fileinfo`.`vid` = `vediorent`.`videoinfo`.`id`) and
         (`vediorent`.`recordinfo`.`fid` = `vediorent`.`fileinfo`.`id`));

