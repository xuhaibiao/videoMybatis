create view userrentalhistory as
  select `vediorent`.`recordinfo`.`username` AS `username`,
         `vediorent`.`vedioinfo`.`name`      AS `name`,
         `vediorent`.`recordinfo`.`fid`      AS `fid`,
         `vediorent`.`recordinfo`.`lend`     AS `lend`,
         `vediorent`.`recordinfo`.`back`     AS `back`,
         `vediorent`.`recordinfo`.`amount`   AS `amount`
  from ((`vediorent`.`recordinfo` join `vediorent`.`vedioinfo`) join `vediorent`.`fileinfo`)
  where ((`vediorent`.`fileinfo`.`vid` = `vediorent`.`vedioinfo`.`id`) and
         (`vediorent`.`recordinfo`.`fid` = `vediorent`.`fileinfo`.`id`));

