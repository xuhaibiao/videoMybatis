create view vediorecording as
  select `vediorent`.`vedioinfo`.`name`      AS `name`,
         `vediorent`.`vedioinfo`.`price`     AS `price`,
         `vediorent`.`vedioinfo`.`inventory` AS `inventory`
  from `vediorent`.`vedioinfo`;

